
public class InvalidCakeIdException extends Exception {

	public InvalidCakeIdException(String message) {
		super(message);
	}

}
