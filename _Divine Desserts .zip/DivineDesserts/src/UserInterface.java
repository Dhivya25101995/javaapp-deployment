import java.util.Scanner;
public class UserInterface {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Utility uObj = new Utility();
		CakeOrder Obj = new CakeOrder();
		int count=0;
		System.out.println("Enter the total number of cakes needed");
		int no = sc.nextInt();
		System.out.println("Enter the Cake details");
		String CakeDetails[] = new String[no];
		String inputproduct[]=new String[no];
		for(int i=0;i<no;i++) 
		{
			CakeDetails[i] = sc.next();
		}
		
		for(int i=0;i<no;i++) {
			String details[]=CakeDetails[i].split(":");
			try 
			{
				boolean flag=uObj.validateCakeId(details[0]);
				if (flag==true)
				{	
					inputproduct[count]=CakeDetails[i];
					count++;
				}					
			}
			catch(InvalidCakeIdException e)
			{
				System.out.println(e.getMessage());
			}
		}
		Cake[] cakeArr=new Cake[count];
		for (int i=0;i<count;i++)
		{	 	  	      	 	    	      	    	      	 	
			String[]input=inputproduct[i].split(":");
			cakeArr[i]=new Cake(input[0],input[1],Double.parseDouble(input[2]),Integer.parseInt(input[3]));
		}
		
		Obj.cakeBooking(cakeArr);		
		if(Obj.getCakeList().size()==0) {
			System.out.println("Your booking is empty");
		} else {
			System.out.println("Enter the UPI name to avail offer");
			String UPIName = sc.next();
			Obj.findDiscount(UPIName);
			System.out.printf("Total Bill Amount: %.2f",Obj.calculateTotalBill());
		}
	}


}
