import java.util.regex.Pattern;

public class Utility {

	public boolean validateCakeId(String cakeId) throws InvalidCakeIdException {
		
		String p = "[C][A][K][E][0-9]{3}";
		if(Pattern.matches(p, cakeId)) {
			return true;
		} else {
			throw new InvalidCakeIdException("Cake Id "+cakeId+" is not valid");
		}
	}
}
 
