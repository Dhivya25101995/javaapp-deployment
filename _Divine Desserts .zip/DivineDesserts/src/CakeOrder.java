import java.util.ArrayList;
import java.util.List;

public class CakeOrder {
	
	private List<Cake> cakeList = new ArrayList<Cake>();
	private double discount;
	
	public List<Cake> getCakeList() {
		return cakeList;
	}
	public void setCakeList(List<Cake> cakeList) {
		this.cakeList = cakeList;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	public void cakeBooking(Cake cakeObject[]) {
		for(Cake c : cakeObject) {
			cakeList.add(c);
		}
		
		setCakeList(cakeList);
	}
	
	public void findDiscount(String UPIName) {
		if(UPIName.equalsIgnoreCase("PhonePe")) {
			setDiscount(25);
		} else if(UPIName.equalsIgnoreCase("GooglePay")) {
			setDiscount(20);
		} else if(UPIName.equalsIgnoreCase("Paytm")) {
			setDiscount(15);
		}	 	  	      	 	    	      	    	      	 	
	}
	
	public double calculateTotalBill() {
		double totalPrice = 0;
		double bill = 0;
		for(int i=0;i<cakeList.size();i++) {
			totalPrice += cakeList.get(i).getQuantity() * cakeList.get(i).getCostPerKg();
		}
		bill = totalPrice - ((totalPrice * getDiscount())/100);
		return bill;
	}

}
